
    function changeImage() {

        if (document.getElementById("imgClickAndChange").src == "") 
        {
            document.getElementById("imgClickAndChange").src = "";
        }
        else 
        {
            document.getElementById("imgClickAndChange").src = "";
        }
    }